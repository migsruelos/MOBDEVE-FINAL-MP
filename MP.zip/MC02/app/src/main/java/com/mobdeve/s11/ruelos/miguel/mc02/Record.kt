package com.mobdeve.s11.ruelos.miguel.mc02

import java.util.*

class Record(var hr : Int,
             var min : Int,
             var sec : Int)    {
    constructor(): this(0,0, 0, )
}